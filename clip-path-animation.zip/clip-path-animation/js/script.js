$(function(){
 $('span.iclick').click(function(){
    //  $('.inner').toggleClass({"background-color": "#fd8cb2", "clip-path": "circle(75%)"});
     $('.inner').toggleClass('clipping-path-full');
    
 });

});